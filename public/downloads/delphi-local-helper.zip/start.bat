@echo off
title Agente Local Delphi
cd /d "%~dp0"

echo ========================================
echo   Agente Local Delphi - Iniciando
echo ========================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERRO] Node.js nao encontrado.
    echo Baixe e instale em: https://nodejs.org
    echo.
    pause
    exit /b 1
)

where ffmpeg >nul 2>nul
if %errorlevel% neq 0 (
    echo [AVISO] FFmpeg nao encontrado no sistema.
    echo Tentando instalar automaticamente com winget...
    winget install --id Gyan.FFmpeg -e --silent
    echo.
    echo Se a instalacao falhar, baixe manualmente em:
    echo https://ffmpeg.org/download.html
    echo e adicione ao PATH do Windows.
    echo.
)

if not exist "node_modules" (
    echo Instalando dependencias pela primeira vez...
    call npm install
    echo.
)

echo Iniciando servidor local...
echo.
node server.js

pause
