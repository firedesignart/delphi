const express = require('express')
const cors = require('cors')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { spawn, execSync } = require('child_process')

const PORT = 7878
const BASE_DIR = path.join(os.homedir(), 'Delphi')
const INPUT_DIR = path.join(BASE_DIR, 'Input')
const OUTPUT_DIR = path.join(BASE_DIR, 'Output')
const TEMP_DIR = path.join(BASE_DIR, '.temp')

for (const dir of [BASE_DIR, INPUT_DIR, OUTPUT_DIR, TEMP_DIR]) {
  fs.mkdirSync(dir, { recursive: true })
}

function checkFFmpeg() {
  try {
    execSync('ffmpeg -version', { stdio: 'ignore' })
    return true
  } catch {
    return false
  }
}

const hasFFmpeg = checkFFmpeg()

const app = express()
app.use(cors())
app.use((req, res, next) => {
  // Necessário porque o site Delphi usa COEP (Cross-Origin-Embedder-Policy) para o FFmpeg WASM
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin')
  next()
})
app.use(express.json({ limit: '50mb' }))

const VIDEO_EXT = ['.mp4', '.mov', '.mkv', '.avi', '.webm']

app.get('/health', (req, res) => {
  res.json({ ok: true, ffmpeg: hasFFmpeg, inputDir: INPUT_DIR, outputDir: OUTPUT_DIR })
})

app.get('/files', (req, res) => {
  try {
    const files = fs
      .readdirSync(INPUT_DIR)
      .filter((f) => VIDEO_EXT.includes(path.extname(f).toLowerCase()))
      .map((f) => {
        const stat = fs.statSync(path.join(INPUT_DIR, f))
        return { name: f, size: stat.size, modified: stat.mtimeMs }
      })
      .sort((a, b) => b.modified - a.modified)
    res.json({ files })
  } catch (err) {
    res.status(500).json({ error: String(err) })
  }
})

// Stream com suporte a Range para o player de vídeo do navegador
app.get('/stream/:filename', (req, res) => {
  const filePath = path.join(INPUT_DIR, req.params.filename)
  if (!filePath.startsWith(INPUT_DIR) || !fs.existsSync(filePath)) {
    return res.status(404).end()
  }
  const stat = fs.statSync(filePath)
  const range = req.headers.range
  if (!range) {
    res.writeHead(200, { 'Content-Length': stat.size, 'Content-Type': 'video/mp4' })
    return fs.createReadStream(filePath).pipe(res)
  }
  const [startStr, endStr] = range.replace(/bytes=/, '').split('-')
  const start = parseInt(startStr, 10)
  const end = endStr ? parseInt(endStr, 10) : stat.size - 1
  res.writeHead(206, {
    'Content-Range': `bytes ${start}-${end}/${stat.size}`,
    'Accept-Ranges': 'bytes',
    'Content-Length': end - start + 1,
    'Content-Type': 'video/mp4',
  })
  fs.createReadStream(filePath, { start, end }).pipe(res)
})

app.post('/extract-audio', (req, res) => {
  const { filename } = req.body
  const inputPath = path.join(INPUT_DIR, filename)
  if (!inputPath.startsWith(INPUT_DIR) || !fs.existsSync(inputPath)) {
    return res.status(404).json({ error: 'Arquivo não encontrado em Delphi/Input' })
  }
  const outPath = path.join(TEMP_DIR, `audio_${Date.now()}.mp3`)

  const ff = spawn('ffmpeg', ['-i', inputPath, '-vn', '-ac', '1', '-ar', '16000', '-b:a', '64k', '-y', outPath])
  ff.on('close', (code) => {
    if (code !== 0 || !fs.existsSync(outPath)) {
      return res.status(500).json({ error: 'FFmpeg falhou ao extrair áudio' })
    }
    res.setHeader('Content-Type', 'audio/mpeg')
    const stream = fs.createReadStream(outPath)
    stream.pipe(res)
    stream.on('close', () => fs.unlink(outPath, () => {}))
  })
  ff.on('error', (err) => res.status(500).json({ error: String(err) }))
})

app.post('/cut-clip', (req, res) => {
  const { filename, startTime, endTime, layout, width, height, outputName } = req.body
  const inputPath = path.join(INPUT_DIR, filename)
  if (!inputPath.startsWith(INPUT_DIR) || !fs.existsSync(inputPath)) {
    return res.status(404).json({ error: 'Arquivo não encontrado em Delphi/Input' })
  }

  const safeName = (outputName || `clip_${Date.now()}`).replace(/[^a-zA-Z0-9_\-]/g, '_')
  const outputPath = path.join(OUTPUT_DIR, `${safeName}.mp4`)
  const duration = endTime - startTime
  const W = width || 1080
  const H = height || 1920

  let args

  if (layout === 'split') {
    // Corta a metade ESQUERDA do quadro original para cima e a DIREITA para baixo —
    // separa duas pessoas lado a lado em vez de duplicar o mesmo recorte central.
    const halfH = Math.round(H / 2)
    const cropExpr = `crop=ih*${W}/${halfH}:ih`
    const filterComplex =
      `[0:v]${cropExpr}:0:0,scale=${W}:${halfH}:flags=lanczos[top];` +
      `[0:v]${cropExpr}:in_w-out_w:0,scale=${W}:${halfH}:flags=lanczos[bot];` +
      `[top][bot]vstack,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:black[vout]`

    args = [
      '-ss', String(startTime), '-t', String(duration), '-i', inputPath,
      '-filter_complex', filterComplex,
      '-map', '[vout]', '-map', '0:a',
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '20',
      '-c:a', 'aac', '-b:a', '128k',
      '-movflags', '+faststart',
      '-y', outputPath,
    ]
  } else {
    let vf
    if (layout === 'letterbox') {
      vf = `scale=${W}:-2:flags=lanczos,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:black`
    } else {
      vf = `scale=${W}:${H}:force_original_aspect_ratio=increase:flags=lanczos,crop=${W}:${H}`
    }

    args = [
      '-ss', String(startTime), '-t', String(duration), '-i', inputPath,
      '-vf', vf,
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '20',
      '-c:a', 'aac', '-b:a', '128k',
      '-movflags', '+faststart',
      '-y', outputPath,
    ]
  }

  const ff = spawn('ffmpeg', args)
  let stderr = ''
  ff.stderr.on('data', (d) => { stderr += d.toString() })
  ff.on('close', (code) => {
    if (code !== 0 || !fs.existsSync(outputPath)) {
      return res.status(500).json({ error: 'FFmpeg falhou ao cortar o clip', detail: stderr.slice(-500) })
    }
    res.json({ ok: true, outputPath, outputDir: OUTPUT_DIR })
  })
  ff.on('error', (err) => res.status(500).json({ error: String(err) }))
})

app.listen(PORT, '127.0.0.1', () => {
  console.log('')
  console.log('========================================')
  console.log('  Agente Local Delphi rodando!')
  console.log('========================================')
  console.log(`  Porta: ${PORT}`)
  console.log(`  FFmpeg detectado: ${hasFFmpeg ? 'SIM' : 'NAO — instale com: winget install ffmpeg'}`)
  console.log(`  Pasta de entrada: ${INPUT_DIR}`)
  console.log(`  Pasta de saida:   ${OUTPUT_DIR}`)
  console.log('')
  console.log('  Coloque seus videos na pasta de entrada e')
  console.log('  volte para o site do Delphi.')
  console.log('')
  console.log('  Deixe esta janela aberta enquanto usa o Delphi.')
  console.log('========================================')
})
